export class EventoModel {
    canBePublished = '';
    eventCharge = '';
    eventClass = '';
    eventCode = '';
    eventComplexity = '';
    eventDescription = '';
    eventLargeDescription = '';
    eventPriority = '';
    eventType = '';
    mandatoryEventInd = '';
    motorCode = '';
    motorDescription = '';
    newEvent = '';
    planCode = '';
    planDescription = '';
}
