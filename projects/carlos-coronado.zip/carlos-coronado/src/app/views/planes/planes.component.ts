import { Component, OnInit } from '@angular/core';
import { AppService } from '../../providers/app.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-planes',
  templateUrl: './planes.component.html',
  styleUrls: ['./planes.component.css']
})
export class PlanesComponent implements OnInit {
  planes$: Observable<any>;

  constructor(private appService: AppService) { }

  ngOnInit() {
    this.planes$ = this.appService.getListadoPlanes();
  }

}
