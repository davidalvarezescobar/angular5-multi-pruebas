import { Component, OnInit } from '@angular/core';
import { AppService } from '../../providers/app.service';
import { switchMap, distinctUntilChanged, debounceTime, tap, merge } from 'rxjs/operators';
import { Observable, BehaviorSubject, Subject } from 'rxjs';
import { StoreEventosService } from '../../providers/store.eventos.service';


@Component({
  selector: 'app-eventos',
  templateUrl: './eventos.component.html',
  styleUrls: ['./eventos.component.css']
})
export class EventosComponent implements OnInit {
  eventos$: Observable<any>;
  searchStream = new Subject();                 // con subject, no realiza una primera búsqueda al cargarse la página
  // searchStream = new BehaviorSubject(null);  // con behaviorsubject, sí
  columna;
  ordenAsc;

  constructor(
    private appService: AppService,
    private eventosService: StoreEventosService
  ) { }

  ngOnInit() {
    const searchList$ = this.searchStream.pipe(
      switchMap((term) => {
        return this.eventosService.getNewListadoEventos(term);
      })
    );
    const initialList$ = this.eventosService.getListadoEventos();
    this.eventos$ = initialList$.pipe(
      merge(searchList$)
    );
  }

  sort(columna) {
    this.ordenAsc = !this.ordenAsc;
    this.columna = columna;
  }

  searchData(term: any) {
    this.searchStream.next(term);
  }

  trackByFn(index: any, item: any) {
    return index;
  }
}
