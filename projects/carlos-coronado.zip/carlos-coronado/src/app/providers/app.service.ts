import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable, pluck, shareReplay, tap } from 'rxjs';


@Injectable()
export class AppService {
  listadoEventos$: Observable<any>;
  listadoPlanes$: Observable<any>;
  combosEvento$: Observable<any>;

  constructor(private http: HttpClient) { }

  getListadoEventos(searchDesc?) {
    if (!this.listadoEventos$ || searchDesc !== null) {
      const url = 'http://180.106.132.72:8083/ANRGBA_RadarAisLP/public/rest/anrgba/admin/event/list';
      const params = {
        'searchReference': '01',
        'requestedListSize': '50',
        'eventDescription': searchDesc
      };
      this.listadoEventos$ = this.http.post(url, params).pipe(
        // take(1), // take no es necesario en peticiones http
        pluck('eventlistItem'),
        // a continuación, un map de rxjs que extrae la lista de datos, más un map de javascript que itera con la lista de datos
        map((list: any[]) => list.map(o => {
          return {id: 'prueba', ...o};
        })),
        shareReplay(),
        tap(list => console.log(list))
      );
    }
    return this.listadoEventos$;
  }

  getListadoPlanes() {
    if (!this.listadoPlanes$) {
      const url = 'http://180.106.132.72:8083/ANRGBA_RadarAisLP/public/rest/anrgba/admin/plan/list';
      const params = {
        'searchReference': '01',
        'requestedListSize': '50',
        'planDescription': null
      };
      this.listadoPlanes$ = this.http.post(url, params).pipe(
        // take(1), // take no es necesario en peticiones http
        pluck('planlistItem'),
        shareReplay()
      );
    }
    return this.listadoPlanes$;
  }

  getCombosEvento() {
    if (!this.combosEvento$) {
      const url = 'http://180.106.132.72:8083/ANRGBA_RadarAisLP/public/rest/anrgba/admin/masterlist';
      const params = {
        comboList: ['MO', 'PR', 'TIE', 'CLE']
      };
      this.combosEvento$ = this.http.post(url, params).pipe(
        // take(1), // take no es necesario en peticiones http
        pluck('comboListResult'),
        map((arr: any[]) => {
          console.log('Array original:', arr);
          const newResult = {};
          for (const {comboCode, comboListData} of arr) {
            newResult[comboCode] = comboListData;
          }
          console.log('Array convertido a objeto:', newResult);
          return newResult;
        }),
        shareReplay()
      );
    }
    return this.combosEvento$;
  }

  clearCache() {
    this.listadoPlanes$ = null;
    this.listadoEventos$ = null;
    this.combosEvento$ = null;
  }

  nuevoEvento(evento) {
    const url = 'http://180.106.132.72:8083/ANRGBA_RadarAisLP/public/rest/anrgba/admin/event/new';
    return this.http.post(url, evento);
  }
}
