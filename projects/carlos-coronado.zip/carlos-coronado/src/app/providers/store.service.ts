import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs';


export abstract class StoreService<T> {
  private _store$: BehaviorSubject<T>;
  readonly store$: Observable<T>;

  constructor(initialState: T) {
    this._store$ = new BehaviorSubject(initialState);
    this.store$ = this._store$.asObservable();
  }

  protected get store(): T {
    return this._store$.value;
  }

  protected set store(state: T) {
    this._store$.next(state);
  }

}
