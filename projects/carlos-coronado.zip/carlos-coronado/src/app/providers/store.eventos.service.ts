import { Injectable } from '@angular/core';
import { StoreService } from './store.service';
import { HttpClient } from '@angular/common/http';
import { tap, map, pluck, Observable } from 'rxjs';


@Injectable()
export class StoreEventosService extends StoreService<any> {

  constructor(private http: HttpClient) {
    super(null);
    this.refreshState();
  }

  getListadoEventos() {
    return this.store$;
  }

  refreshState() {
    this.getNewListadoEventos().subscribe();
  }

  getNewListadoEventos(searchDesc?): Observable<any> {
    const url = 'http://180.106.132.72:8083/ANRGBA_RadarAisLP/public/rest/anrgba/admin/event/list';
    const params = {
      'searchReference': '01',
      'requestedListSize': '50',
      'eventDescription': searchDesc
    };
    return this.http.post(url, params).pipe(
      pluck('eventlistItem'),
      // a continuación, un map de rxjs que extrae la lista de datos, más un map de javascript que itera con la lista de datos
      map((list: any[]) => list.map(o => {
        return {id: 'prueba', ...o};
      })),
      tap(list => console.log(list)),
      tap(data => this.store = data)
    );
  }
}
